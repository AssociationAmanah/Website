import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { projects } from '../data/projectsData';
import { MapPin, Calendar, ChevronLeft } from 'lucide-react';
import Button from '../components/common/Button';
import ImageGallery from '../components/projects/ImageGallery';
import { Project } from '../types';

const ProjectDetailPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [project, setProject] = useState<Project | null>(null);

  useEffect(() => {
    const foundProject = projects.find(p => p.id === id);
    if (foundProject) {
      setProject(foundProject);
    } else {
      navigate('/projets');
    }
  }, [id, navigate]);

  if (!project) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p className="text-xl text-gray-600">Chargement du projet...</p>
      </div>
    );
  }

  return (
    <div className="pt-16">
      {/* Main Image Section */}
      <div className="relative h-[50vh] md:h-[60vh] bg-cover bg-center"
        style={{ backgroundImage: `url(${project.image})` }}>
        <div className="absolute inset-0 bg-black bg-opacity-40"></div>
        <div className="absolute inset-0 flex items-end">
          <div className="container mx-auto px-4 py-8">
            <motion.h1 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="text-3xl md:text-4xl lg:text-5xl font-display font-bold text-white mb-2"
            >
              {project.title}
            </motion.h1>
          </div>
        </div>
      </div>

      {/* Project Content */}
      <div className="container mx-auto px-4 py-12">
        <motion.button
          initial={{ opacity: 0, x: -10 }}
          animate={{ opacity: 1, x: 0 }}
          className="flex items-center text-primary-600 mb-8 hover:text-primary-700 transition-colors"
          onClick={() => navigate('/projets')}
        >
          <ChevronLeft size={20} />
          <span className="ml-1">Retour aux projets</span>
        </motion.button>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
            >
              <h2 className="text-2xl font-display font-bold text-gray-900 mb-4">Description du projet</h2>
              <div className="prose max-w-none text-gray-700 mb-8">
                {project.description.split('\n\n').map((paragraph, idx) => (
                  <p key={idx} className="mb-4">{paragraph}</p>
                ))}
              </div>

              <h2 className="text-2xl font-display font-bold text-gray-900 mb-4">Impact</h2>
              <p className="text-gray-700 mb-8">{project.impact}</p>

              {/* Image Gallery */}
              <h2 className="text-2xl font-display font-bold text-gray-900 mb-4">Galerie</h2>
              <ImageGallery images={project.gallery} />
            </motion.div>
          </div>

          {/* Sidebar */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="bg-gray-50 p-6 rounded-lg shadow-soft"
          >
            <h3 className="text-xl font-display font-bold text-gray-900 mb-4">Informations</h3>
            
            <div className="flex items-start mb-4">
              <MapPin className="w-5 h-5 text-secondary-500 mt-0.5 mr-2" />
              <div>
                <p className="font-semibold text-gray-800">Lieu</p>
                <p className="text-gray-600">{project.location}</p>
              </div>
            </div>

            <div className="flex items-start mb-6">
              <Calendar className="w-5 h-5 text-secondary-500 mt-0.5 mr-2" />
              <div>
                <p className="font-semibold text-gray-800">Date</p>
                <p className="text-gray-600">{project.date}</p>
              </div>
            </div>

            <div className="mt-8">
              <Button variant="primary" fullWidth onClick={() => navigate('/don')}>
                Soutenir ce projet
              </Button>
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
};

export default ProjectDetailPage;