import React from 'react';
import Hero from '../components/common/Hero';
import AboutSection from '../components/home/AboutSection';
import FeaturedProjects from '../components/home/FeaturedProjects';
import DonationCTA from '../components/home/DonationCTA';
import ContactForm from '../components/common/ContactForm';

const HomePage: React.FC = () => {
  return (
    <div>
      <Hero 
        title="Ensemble pour un monde meilleur"
        subtitle="Créer un impact durable à travers des projets humanitaires en Afrique"
        backgroundImage="https://images.pexels.com/photos/935948/pexels-photo-935948.jpeg"
      />
      <AboutSection />
      <FeaturedProjects />
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="max-w-2xl mx-auto">
            <ContactForm />
          </div>
        </div>
      </section>
      <DonationCTA />
    </div>
  );
};

export default HomePage;