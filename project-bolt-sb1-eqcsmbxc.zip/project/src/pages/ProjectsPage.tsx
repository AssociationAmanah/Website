import React from 'react';
import Hero from '../components/common/Hero';
import ProjectGrid from '../components/projects/ProjectGrid';

const ProjectsPage: React.FC = () => {
  return (
    <div>
      <Hero 
        title="Nos Projets"
        subtitle="Découvrez nos initiatives humanitaires à travers l'Afrique"
        backgroundImage="https://images.pexels.com/photos/6646918/pexels-photo-6646918.jpeg"
      />
      <ProjectGrid />
    </div>
  );
};

export default ProjectsPage;