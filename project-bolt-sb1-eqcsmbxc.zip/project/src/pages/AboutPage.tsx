import React from 'react';
import Hero from '../components/common/Hero';
import { motion } from 'framer-motion';
import { Heart, Users, Globe, Target, Award, Clock } from 'lucide-react';
import ContactForm from '../components/common/ContactForm';

const AboutPage: React.FC = () => {
  const values = [
    {
      icon: <Heart className="w-8 h-8 text-secondary-500" />,
      title: 'Compassion',
      description: 'Nous agissons avec empathie et respect envers les personnes que nous aidons.'
    },
    {
      icon: <Users className="w-8 h-8 text-secondary-500" />,
      title: 'Solidarité',
      description: 'Nous croyons en la force de la communauté et au pouvoir de l\'entraide.'
    },
    {
      icon: <Globe className="w-8 h-8 text-secondary-500" />,
      title: 'Responsabilité',
      description: 'Nous nous engageons à utiliser les ressources de manière éthique et transparente.'
    },
    {
      icon: <Target className="w-8 h-8 text-secondary-500" />,
      title: 'Impact',
      description: 'Nous visons des changements durables qui renforcent l\'autonomie des communautés.'
    },
    {
      icon: <Award className="w-8 h-8 text-secondary-500" />,
      title: 'Excellence',
      description: 'Nous nous efforçons d\'atteindre les plus hauts standards dans toutes nos actions.'
    },
    {
      icon: <Clock className="w-8 h-8 text-secondary-500" />,
      title: 'Durabilité',
      description: 'Nous concevons nos projets pour qu\'ils aient un impact positif à long terme.'
    }
  ];

  return (
    <div>
      <Hero 
        title="À Propos de Nous"
        subtitle="Découvrez notre histoire, notre mission et nos valeurs"
        backgroundImage="https://images.pexels.com/photos/6647037/pexels-photo-6647037.jpeg"
      />
      
      {/* History & Mission */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
              className="text-center mb-12"
            >
              <h2 className="text-3xl font-display font-bold text-gray-900 mb-4">
                Notre Histoire
              </h2>
              <p className="text-lg text-gray-700 mb-6">
                Fondée en 2013, l'Association Amanah est née de la volonté de créer un changement 
                significatif et durable dans la vie des populations les plus vulnérables d'Afrique.
              </p>
              <p className="text-lg text-gray-700 mb-6">
                Après avoir été témoin des défis auxquels font face de nombreuses communautés rurales, 
                notre fondatrice Marie Dupont a rassemblé une équipe de professionnels partageant la 
                même vision pour lancer des projets humanitaires centrés sur l'accès à l'eau, 
                l'éducation, la santé et la sécurité alimentaire.
              </p>
              <p className="text-lg text-gray-700">
                Au fil des années, nous avons élargi notre portée et notre impact, tout en restant 
                fidèles à notre engagement d'autonomiser les communautés à travers des solutions durables.
              </p>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="text-center mb-12"
            >
              <h2 className="text-3xl font-display font-bold text-gray-900 mb-4">
                Notre Mission
              </h2>
              <p className="text-lg text-gray-700">
                L'Association Amanah a pour mission d'améliorer les conditions de vie des populations 
                les plus vulnérables à travers des projets humanitaires durables et impactants. 
                Nous croyons fermement que chaque personne mérite l'accès aux ressources essentielles 
                et aux opportunités qui lui permettront de construire un avenir meilleur.
              </p>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Our Values */}
      <section className="py-16 bg-primary-50">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="text-center mb-12"
          >
            <h2 className="text-3xl font-display font-bold text-gray-900 mb-4">
              Nos Valeurs
            </h2>
            <p className="text-lg text-gray-700 max-w-2xl mx-auto">
              Ces principes fondamentaux guident toutes nos actions et décisions.
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {values.map((value, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                className="bg-white p-6 rounded-lg shadow-soft hover:shadow-hover transition-shadow"
              >
                <div className="mb-4">
                  {value.icon}
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-2">
                  {value.title}
                </h3>
                <p className="text-gray-600">
                  {value.description}
                </p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Form */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="max-w-2xl mx-auto">
            <ContactForm />
          </div>
        </div>
      </section>
    </div>
  );
};

export default AboutPage;