import React from 'react';
import { Link } from 'react-router-dom';
import { Heart, Mail, Phone, MapPin, Facebook, Instagram } from 'lucide-react';
import { socialLinks } from '../../data/projectsData';

const Footer: React.FC = () => {
  return (
    <footer className="bg-gray-900 text-white pt-16 pb-8">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Association Info */}
          <div>
            <h3 className="font-display font-bold text-xl mb-4">Association Amanah</h3>
            <p className="text-gray-300 mb-4">
              Ensemble pour un monde meilleur à travers des projets humanitaires durables et impactants.
            </p>
            <div className="flex space-x-4 mt-4">
              {socialLinks.map((link) => (
                <a
                  key={link.platform}
                  href={link.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-white hover:text-secondary-400 transition-colors"
                  aria-label={link.platform}
                >
                  {link.icon === 'facebook' ? (
                    <Facebook size={20} />
                  ) : (
                    <Instagram size={20} />
                  )}
                </a>
              ))}
            </div>
          </div>

          {/* Navigation Links */}
          <div>
            <h3 className="font-display font-bold text-xl mb-4">Navigation</h3>
            <ul className="space-y-2">
              <li>
                <Link to="/" className="text-gray-300 hover:text-white transition-colors">
                  Accueil
                </Link>
              </li>
              <li>
                <Link to="/projets" className="text-gray-300 hover:text-white transition-colors">
                  Nos Projets
                </Link>
              </li>
              <li>
                <Link to="/don" className="text-gray-300 hover:text-white transition-colors">
                  Faire un don
                </Link>
              </li>
              <li>
                <Link to="/a-propos" className="text-gray-300 hover:text-white transition-colors">
                  À propos
                </Link>
              </li>
            </ul>
          </div>

          {/* Contact Information */}
          <div>
            <h3 className="font-display font-bold text-xl mb-4">Contact</h3>
            <ul className="space-y-3">
              <li className="flex items-start">
                <MapPin size={18} className="mr-2 mt-1 flex-shrink-0 text-secondary-400" />
                <span className="text-gray-300">
                  123 Rue de l'Espoir, 75001 Paris, France
                </span>
              </li>
              <li className="flex items-center">
                <Phone size={18} className="mr-2 flex-shrink-0 text-secondary-400" />
                <span className="text-gray-300">+33 1 23 45 67 89</span>
              </li>
              <li className="flex items-center">
                <Mail size={18} className="mr-2 flex-shrink-0 text-secondary-400" />
                <a href="mailto:contact@association-amanah.org" className="text-gray-300 hover:text-white transition-colors">
                  contact@association-amanah.org
                </a>
              </li>
            </ul>
          </div>

          {/* Newsletter */}
          <div>
            <h3 className="font-display font-bold text-xl mb-4">Newsletter</h3>
            <p className="text-gray-300 mb-4">
              Inscrivez-vous pour recevoir nos actualités et suivre nos projets.
            </p>
            <form className="flex flex-col space-y-2">
              <input
                type="email"
                placeholder="Votre email"
                className="px-4 py-2 rounded bg-gray-800 border border-gray-700 text-white focus:outline-none focus:ring-2 focus:ring-primary-500"
              />
              <button
                type="submit"
                className="bg-primary-600 hover:bg-primary-700 text-white px-4 py-2 rounded transition-colors"
              >
                S'inscrire
              </button>
            </form>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="border-t border-gray-800 mt-12 pt-8 flex flex-col md:flex-row justify-between items-center">
          <p className="text-gray-400 text-sm mb-4 md:mb-0">
            &copy; {new Date().getFullYear()} Association Amanah. Tous droits réservés.
          </p>
          <div className="flex items-center text-gray-400 text-sm">
            <span>Créé avec</span>
            <Heart size={14} className="mx-1 text-secondary-500" />
            <span>pour un monde meilleur</span>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;