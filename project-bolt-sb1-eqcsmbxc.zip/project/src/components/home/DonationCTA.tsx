import React from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import Button from '../common/Button';

const DonationCTA: React.FC = () => {
  return (
    <section className="py-20 bg-primary-600 text-white">
      <div className="container mx-auto px-4">
        <div className="max-w-3xl mx-auto text-center">
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="text-3xl md:text-4xl font-display font-bold mb-6"
          >
            Ensemble, nous pouvons faire la différence
          </motion.h2>
          
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="text-lg mb-8 text-primary-100"
          >
            Votre générosité permet de financer des projets essentiels et de transformer des vies.
            Chaque contribution, quelle que soit sa taille, a un impact significatif.
          </motion.p>
          
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.2 }}
          >
            <Link to="/don">
              <Button
                variant="secondary"
                size="lg"
                className="px-8 py-3 text-lg"
              >
                Faire un don maintenant
              </Button>
            </Link>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default DonationCTA;