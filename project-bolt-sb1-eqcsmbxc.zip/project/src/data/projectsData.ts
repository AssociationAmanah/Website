import { Project, ImpactStat, Testimonial } from '../types';

export const projects: Project[] = [
  {
    id: '1',
    title: 'Eau potable pour tous',
    summary: 'Création de puits et accès à l\'eau potable dans des villages isolés au Sénégal.',
    description: `Notre projet "Eau potable pour tous" vise à garantir un accès durable à l'eau potable pour les communautés isolées du Sénégal. En collaboration avec les autorités locales et des ingénieurs hydrauliques, nous avons pu installer des systèmes de pompage solaire et creuser des puits profonds qui desservent plus de 5000 personnes.

    Les installations comprennent:
    - 3 puits profonds équipés de pompes solaires
    - Un système de filtration et de purification de l'eau
    - Des réservoirs de stockage d'une capacité totale de 30 000 litres
    - Des points d'eau répartis stratégiquement dans les villages

    Ce projet a considérablement réduit les maladies d'origine hydrique et a libéré du temps pour les femmes et les enfants qui parcouraient auparavant plusieurs kilomètres pour collecter de l'eau.`,
    location: 'Sénégal',
    image: 'https://images.pexels.com/photos/2122406/pexels-photo-2122406.jpeg',
    gallery: [
      'https://images.pexels.com/photos/1327601/pexels-photo-1327601.jpeg',
      'https://images.pexels.com/photos/2531299/pexels-photo-2531299.jpeg',
      'https://images.pexels.com/photos/3280130/pexels-photo-3280130.jpeg'
    ],
    date: 'Janvier 2023',
    impact: 'Plus de 5000 personnes ont désormais accès à l\'eau potable.'
  },
  {
    id: '2',
    title: 'Education pour l\'avenir',
    summary: 'Construction d\'écoles et fourniture de matériel scolaire au Mali.',
    description: `Le projet "Education pour l'avenir" s'attaque directement aux obstacles à l'éducation dans les zones rurales du Mali. Notre intervention s'est déployée sur trois axes principaux :
    
    1. Infrastructure : Nous avons construit deux nouvelles écoles avec 12 salles de classe au total, des blocs sanitaires séparés pour filles et garçons, et des espaces récréatifs sécurisés.
    
    2. Matériel pédagogique : Distribution de plus de 1000 kits scolaires complets (livres, cahiers, stylos), installation de bibliothèques avec plus de 500 ouvrages dans chaque école, et fourniture de matériel didactique aux enseignants.
    
    3. Formation : Nous avons formé 15 enseignants locaux aux méthodes pédagogiques modernes et participatives, avec un accent particulier sur l'inclusion des filles et des enfants en situation de handicap.
    
    Ce projet, mené en collaboration avec le ministère de l'Éducation et les communautés locales, a permis d'augmenter le taux de scolarisation de 45% à 78% dans la région ciblée.`,
    location: 'Mali',
    image: 'https://images.pexels.com/photos/8500320/pexels-photo-8500320.jpeg',
    gallery: [
      'https://images.pexels.com/photos/256541/pexels-photo-256541.jpeg',
      'https://images.pexels.com/photos/8500283/pexels-photo-8500283.jpeg',
      'https://images.pexels.com/photos/8471899/pexels-photo-8471899.jpeg'
    ],
    date: 'Septembre 2022',
    impact: '850 élèves bénéficient désormais d\'un enseignement de qualité.'
  },
  {
    id: '3',
    title: 'Sécurité alimentaire',
    summary: 'Programme d\'agriculture durable et de formation aux techniques agricoles au Burkina Faso.',
    description: `Notre initiative de sécurité alimentaire au Burkina Faso combine agriculture durable, innovation et renforcement des capacités locales. Ce programme complet comprend:

    - Mise en place de 5 fermes communautaires utilisant des techniques agroécologiques adaptées au climat local
    - Formation de 250 agriculteurs (dont 60% de femmes) aux techniques d'agriculture résiliente au changement climatique
    - Installation de systèmes d'irrigation goutte-à-goutte économes en eau
    - Introduction de variétés de semences résistantes à la sécheresse
    - Création de 3 coopératives agricoles pour améliorer l'accès aux marchés
    
    Ces actions ont permis d'augmenter les rendements agricoles de 70% en moyenne, tout en réduisant la consommation d'eau de 40%. Les revenus des ménages participants ont augmenté d'environ 35%, améliorant significativement la résilience alimentaire de toute la région.`,
    location: 'Burkina Faso',
    image: 'https://images.pexels.com/photos/2252584/pexels-photo-2252584.jpeg',
    gallery: [
      'https://images.pexels.com/photos/2886937/pexels-photo-2886937.jpeg',
      'https://images.pexels.com/photos/2889434/pexels-photo-2889434.jpeg',
      'https://images.pexels.com/photos/1111597/pexels-photo-1111597.jpeg'
    ],
    date: 'Mars 2023',
    impact: '250 familles ont vu leur production agricole augmenter de 70%.'
  },
  {
    id: '4',
    title: 'Santé pour tous',
    summary: 'Mise en place de cliniques mobiles et formation de personnel médical local au Tchad.',
    description: `Le projet "Santé pour tous" répond aux besoins médicaux critiques des populations rurales isolées au Tchad. Notre approche multidimensionnelle comprend:

    1. Cliniques mobiles: 4 unités médicales mobiles équipées pour les soins primaires, la vaccination, les consultations prénatales et le dépistage des maladies courantes
    
    2. Formation médicale: 30 agents de santé communautaire formés aux premiers secours, à la prévention des maladies et aux soins de base
    
    3. Médicaments essentiels: Approvisionnement régulier en médicaments essentiels, vaccins et fournitures médicales
    
    4. Éducation sanitaire: Campagnes de sensibilisation sur l'hygiène, la nutrition, la santé maternelle et infantile
    
    Depuis son lancement, le programme a permis de réaliser plus de 15 000 consultations médicales et a réduit l'incidence des maladies infectieuses de 35% dans les zones desservies. La mortalité infantile a diminué de 25%, et l'accès aux soins prénatals a augmenté de 60%.`,
    location: 'Tchad',
    image: 'https://images.pexels.com/photos/263402/pexels-photo-263402.jpeg',
    gallery: [
      'https://images.pexels.com/photos/6823553/pexels-photo-6823553.jpeg',
      'https://images.pexels.com/photos/5473182/pexels-photo-5473182.jpeg',
      'https://images.pexels.com/photos/139398/himalayas-monastery-buddhism-buddhist-139398.jpeg'
    ],
    date: 'Juin 2023',
    impact: 'Plus de 15 000 personnes ont reçu des soins médicaux essentiels.'
  }
];

export const impactStats: ImpactStat[] = [
  { value: '25+', label: 'Projets réalisés' },
  { value: '4', label: 'Pays d\'intervention' },
  { value: '50 000+', label: 'Bénéficiaires' },
  { value: '10', label: 'Années d\'expérience' }
];

export const testimonials: Testimonial[] = [
  {
    id: '1',
    name: 'Fatou Diallo',
    role: 'Bénéficiaire, Sénégal',
    quote: 'Grâce au puits installé par Association Amanah, nos enfants n\'ont plus à marcher des kilomètres chaque jour pour chercher de l\'eau. Cela a changé nos vies.',
    image: 'https://images.pexels.com/photos/7048043/pexels-photo-7048043.jpeg'
  },
  {
    id: '2',
    name: 'Ibrahim Koné',
    role: 'Directeur d\'école, Mali',
    quote: 'Les nouvelles infrastructures et le matériel fournis par Amanah ont transformé notre école. Nos élèves sont maintenant enthousiastes à l\'idée d\'apprendre et leurs résultats s\'améliorent constamment.',
    image: 'https://images.pexels.com/photos/5417678/pexels-photo-5417678.jpeg'
  },
  {
    id: '3',
    name: 'Aminata Traoré',
    role: 'Agricultrice, Burkina Faso',
    quote: 'Les techniques agricoles que j\'ai apprises avec Amanah m\'ont permis de tripler ma production. Maintenant, je peux nourrir ma famille et vendre le surplus au marché.',
    image: 'https://images.pexels.com/photos/6177537/pexels-photo-6177537.jpeg'
  }
];

export const socialLinks = [
  {
    platform: 'Facebook',
    url: 'https://facebook.com/associationamanah',
    icon: 'facebook'
  },
  {
    platform: 'Instagram',
    url: 'https://instagram.com/association_amanah',
    icon: 'instagram'
  }
];